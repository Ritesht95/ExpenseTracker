:::::::::EXPENSE TRACKER:::::::::


-> This application helps to track your daily expenses.

-> It is built in PHP with MySQL for the database.


-----------REQUIREMENTS-----------


-> OS: Windows(XAMPP) or Linux(LAMPP)

-> Browser : Firefox, Chrome, Microsoft Edge

-> Internet Connectivity

-> XAMPP or LAMPP according to Operating System as shown above (with PHP and MySQL)



-----------INSTALLATION PROCESS-----------


1. Start Apache and MySQL from XAMPP or LAMPP.

2. Open PHPMyAdmin.

3. Import the Database from the file with the name exptrackerdb.sql(Database Name: "exptracker").

4. Put ExpenseTracker Folder in htdocs(in XAMPP folder).

5. Go to "localhost/ExpenseTracker/" in your web-browser.



 - Ritesh Tailor(rdtailor@gmail.com)